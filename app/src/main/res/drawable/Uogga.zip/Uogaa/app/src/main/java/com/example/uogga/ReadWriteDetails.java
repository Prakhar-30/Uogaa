package com.example.uogga;

public class ReadWriteDetails {
    public String username, mobile, age;

    public ReadWriteDetails(String mobile, String username, String age) {
        this.mobile = mobile;
        this.username = username;
        this.age = age;
    }
}